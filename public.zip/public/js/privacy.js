$(function() {

    // window.addEventListener('privacyPolicyChange', event => {

    //     //
    //     var easyMDE = new EasyMDE({element: $('#privacyPolicyEditor')[0]});
    //     var currentVal = event.detail.value;
    //     easyMDE.value(currentVal);
    //     const input = document.querySelector('#privacyPolicy');
    //     easyMDE.codemirror.on("change", function(){
    //         // $("#privacyPolicy").val( easyMDE.value() );
    //         input.dispatchEvent(new CustomEvent('input',{
    //             detail: easyMDE.value(),
    //             bubbles: true,
    //         }));
    //     });



    // })



});
